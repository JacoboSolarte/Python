package herenciaAnimal;

import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre del gato: ");
        String catName = scanner.nextLine();
        Cat cat = new Cat(catName);

        System.out.print("Ingrese el nombre del primer perro: ");
        String dog1Name = scanner.nextLine();
        Dog dog1 = new Dog(dog1Name);

        System.out.print("Ingrese el nombre del segundo perro: ");
        String dog2Name = scanner.nextLine(); 
        Dog dog2 = new Dog(dog2Name);

        System.out.println(cat);
        System.out.println("Nombre del gato: " + catName);
        cat.greets();

        System.out.println(dog1);
        System.out.println("Nombre del primer perro: " + dog1Name);
        dog1.greets();

        dog1.greets(dog2);
        System.out.println(dog2);
        System.out.println("Nombre del segundo perro: " + dog2Name);
        dog2.greets();
        dog1.greets(dog2);

        scanner.close();
    }
}
