/**
 * 
 */
/**
 * 
 */
module herenciaAnimal {
}