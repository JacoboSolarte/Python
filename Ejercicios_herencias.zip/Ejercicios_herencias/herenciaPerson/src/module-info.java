/**
 * 
 */
/**
 * 
 */
module herenciaPerson {
}